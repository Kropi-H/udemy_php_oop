  </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- WYSIWYG Editor -->
    <script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
    <script src="js/scripts.js" type="text/javascript">

    </script>

</body>

</html>
