    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    <span style="text-transform:uppercase;">Admin</span>
                    <small></small>
                </h1>
                <?php
                     // $photo = Photo::find_by_id(31);
                     // echo $photo->title;


                  // $user = new User();
                  // $user->username = "baby";
                  // $user->password = "24.12.0000";
                  // $user->first_name = "jezisek";
                  // $user->last_name = "robatko";
                  //
                  // $user->create();

                  // $user = User::find_by_id(28);
                  // $user->delete();

                  // $user = User::find_user_by_id(9);
                  // $user->username = "bloodsuck";
                  // $user->update();

                  // $user =new User();
                  // $user->username = "Axík";
                  // $user->save();

                  // $users = User::find_all();
                  // foreach ($users as $user){
                  //   echo $user->username;
                  // }

                  // $photos = Photo::find_all();
                  // foreach ($photos as $photo){
                  //   echo $photo->id . "<br />";
                  //   echo $photo->title . "<br />";
                  //   echo $photo->description . "<br />";
                  //   echo $photo->filename . "<br />";
                  //   echo $photo->type . "<br />";
                  //   echo $photo->size . "<br />";
                  // }

                  // $photo = new Photo();
                  // $photo->title = "photo_from_web";
                  // $photo->description = "this is my new push photo right from the webpage";
                  // $photo->filename = "fotecka_c_002.png";
                  // $photo->type = "image";
                  // $photo->size = 103;
                  //
                  // $photo->create();

                  // $photo = Photo::find_by_id(6);
                  // $photo->delete();

                  // echo INCLUDES_PATH;
                  // echo "<br />";
                  // echo SITE_ROOT;

                 ?>
                <ol class="breadcrumb">
                    <li>
                        <i class="fa fa-dashboard"></i> <a href="index.html">Dashboard</a>
                    </li>
                    <li class="active">
                        <i class="fa fa-file"></i> Blank Page
                    </li>
                </ol>
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container-fluid -->
