
               <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="index.php"><i class="fa fa-fw fa-tachometer"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="users.php"><i class="fa fa-fw fa-user"></i> Users</a>
                    </li>
                    <li>
                        <a href="upload.php"><i class="fa fa-fw fa-upload"></i> Upload</a>
                    </li>
                    <li>
                        <a href="photos.php"><i class="fa fa-fw fa-image"></i> Photos</a>
                    </li>                    
                    <li>
                        <a href="comment.php"><i class="fa fa-fw fa-comment"></i> Comments</a>
                    </li>
                </ul>
            </div>
        <!-- /.navbar-collapse -->