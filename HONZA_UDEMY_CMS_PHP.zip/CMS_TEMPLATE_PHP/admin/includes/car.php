<?php

class Car {
    
    public function run(){
        
        echo "<h1>Hello, this is running!</h1>";
    }
}



?>