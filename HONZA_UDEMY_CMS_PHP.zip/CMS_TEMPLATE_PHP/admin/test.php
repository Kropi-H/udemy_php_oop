<?php

include("includes/header.php");

$auto = new Car;

$auto->run();

?>